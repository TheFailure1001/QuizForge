
let vocabList = [];

function addWord() {
    const wordInput = document.getElementById('word');
    const definitionInput = document.getElementById('definition');

    const word = wordInput.value.trim();
    const definition = definitionInput.value.trim();

    if (word && definition) {
        vocabList.push({ word, definition });
        wordInput.value = '';
        definitionInput.value = '';
        displayVocab();
    } else {
        alert("Please enter both a word and a definition.");
    }
}

function displayVocab() {
    const quizList = document.getElementById('quizList');
    quizList.innerHTML = '';

    vocabList.forEach((item) => {
        const listItem = document.createElement('li');
        listItem.textContent = `${item.word}: ${item.definition}`;
        quizList.appendChild(listItem);
    });
}

function startQuiz() {
    if (vocabList.length === 0) {
        alert("Please add some words before starting the quiz.");
        return;
    }

    alert("Quiz started! Use the console to check the questions and answers.");
    vocabList.forEach(item => {
        const userAnswer = prompt(`What is the definition of "${item.word}"?`);
        if (userAnswer.toLowerCase() === item.definition.toLowerCase()) {
            console.log(`Correct! "${item.word}" means "${item.definition}".`);
        } else {
            console.log(`Wrong! "${item.word}" means "${item.definition}".`);
        }
    });
}
